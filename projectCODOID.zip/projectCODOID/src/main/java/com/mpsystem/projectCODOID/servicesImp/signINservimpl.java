package com.mpsystem.projectCODOID.servicesImp;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mpsystem.projectCODOID.model.signIN;
import com.mpsystem.projectCODOID.repository.signINrepo;
import com.mpsystem.projectCODOID.services.signINservi;

@Service
public class signINservimpl implements signINservi {

	@Autowired
	signINrepo signrep;
	
	@Override
	public List<signIN> getAllsignin() {
		
		List<signIN>sig= signrep.findAll();
		return sig;
		
	}

	@Override
	public  signIN getsignin(Long sid) {
	Optional<signIN> sig1=signrep.findById(sid);
	 signIN sig=sig1.get();
		return sig;
	}
	@Override
	public void insertsignin(signIN s) {
		// TODO Auto-generated method stub
		signrep.save(s);
	}
	@Override
	public void updatesignin(signIN s) {
		 
		signrep.save(s);
		
	}

	@Override
	public void deletesignin(signIN s) {
		// TODO Auto-generated method stub
		signrep.delete(s);
	}

	

}
