package com.mpsystem.projectCODOID.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mpsystem.projectCODOID.model.signIN;
import com.mpsystem.projectCODOID.services.signINservi;



@RestController
public class signContro {
	@Autowired
	signINservi signINservi;
	
	@RequestMapping(value="/getAllsignin")
	public List<signIN> getAllsignin(){
		
		return signINservi.getAllsignin() ;
		
	}
	@RequestMapping(value="/getsignin")
	public  signIN getsignin(Long sid) {
		return signINservi.getsignin(sid);
		
	}
	@PostMapping(value = "/insertsignin")
	public void insertsignin(signIN s) {
		signINservi.insertsignin(s);
	}
	@PutMapping(value = "/updatesignin")
	public void updatesignin(signIN s) {
		 signINservi.updatesignin(s);
		
	}
	@DeleteMapping(value = "/deletesignin")
	public void deletesignin(signIN s) {
		signINservi.deletesignin(s);
	}
	
	

}
