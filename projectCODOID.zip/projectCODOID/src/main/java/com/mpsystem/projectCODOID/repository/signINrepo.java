package com.mpsystem.projectCODOID.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mpsystem.projectCODOID.model.signIN;

@Repository
public interface signINrepo extends JpaRepository<signIN, Long> {


	

	

	

	
	
	

}
