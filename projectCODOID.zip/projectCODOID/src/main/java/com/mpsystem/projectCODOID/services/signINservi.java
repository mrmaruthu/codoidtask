package com.mpsystem.projectCODOID.services;

import java.util.List;

import com.mpsystem.projectCODOID.model.signIN;

public interface signINservi {
	
	public List<signIN> getAllsignin();
	public  signIN getsignin(Long sid);
	public void insertsignin(signIN s);
	public void updatesignin(signIN s);

   public	void deletesignin(signIN sid);
	
	

}
