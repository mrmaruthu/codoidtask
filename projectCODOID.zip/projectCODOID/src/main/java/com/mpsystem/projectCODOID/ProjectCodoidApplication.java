package com.mpsystem.projectCODOID;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectCodoidApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectCodoidApplication.class, args);
	}

}
